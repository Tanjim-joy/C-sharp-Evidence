﻿namespace EvidanceXm
{
    public class VehicleType
    {
    }
}